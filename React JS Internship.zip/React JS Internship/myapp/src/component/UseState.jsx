// import React,{useState} from 'react'

// export default function UseState() {
//     const[state,setState]=useState('Shafina')

//     const HandleClick=()=>{
//         setState('Rahul')
//     }
//     //class Task
//     const[num,setNum]=useState(0)

//     const IncrementNum=()=>{
//         setNum(num+1)
//     }

//     const[Data,setData]=useState({})
//      console.log(Data);

//     const HandleChange=(e)=>{   // e means event (e) or(event)
//         // console.log(e);
//         // console.log(e.target.name)
//         //  console.log(e.target.value);
//         // setData(e.target.value);
//         setData({...Data,[e.target.name]:e.target.value})
//     }
    
//   return (
//     <div>
//         <h1>{state}</h1>
//         <button onClick={HandleClick}>click</button>

//         <h3>{num}</h3>
//         <button onClick={IncrementNum}>Click</button><br></br>

//         {/* // input field only onChange */}
//         <input type="text" name='Myname' placeholder='Enter your name' onChange={HandleChange}/>
//         <input type="text" name='Myphone' placeholder='Enter your phone num' onChange={HandleChange}/>
//     </div>
//   )
// }

// Task-1: changing background -light and dark mode

import React, { useState } from 'react';

export default function TextWithModeToggle() {
// const [displayText, setDisplayText] = useState('useState');
  const [isLightMode, setIsLightMode] = useState(true);

  const handleModeToggle = () => {
    setIsLightMode(!isLightMode);
  };

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    backgroundColor: isLightMode ? 'white' : 'black',
    color: isLightMode ? 'black' : 'white',
  };

  const buttonStyle = {
    marginTop: '20px',
    padding: '10px',
   cursor:'pointer',
  };
  

  return (
    <div style={containerStyle}>
        {/* <h1 style={{ fontSize: '3em' }}>{displayText}</h1> */}
      <h1 style={{ fontSize: '3em' }}>useState</h1>
      <button style={buttonStyle} onClick={handleModeToggle}>
        {isLightMode ? 'Dark Mode' : 'Light Mode'}
      </button>
    </div>
  );
}



