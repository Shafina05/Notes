import React from 'react'
import Logo from './Image/watch.jpeg'//for img -(creat image folder in "src")

export default function SpreadOperator() {
    // 2 array []
    const a=['1','2','3'];// var a=[1,2,3];
    const b=['5','6','7'];
    const c=[...a,...b]//(...)3 dots are used for spreadoperator -to combine the value it is used

    // object -{ }
    const myVehicle={
        brand:'Ford',
        model:'Mustang',
        color:'red',
    }
    const updatemyVehicle={
        brand:'BMW',
    }
    const d={...myVehicle,...updatemyVehicle}
    console.log(d)

    return (
    <div>
        <h1 style={{color:'red',backgroundColor:'black'}}>SpreadOperator</h1>
        <h2>{a}</h2>
        <h2>{b}</h2>
        <h2>{c}</h2>

        {/* Day_10 :To insert image in react */}
    <img src={Logo} alt=" " style={{width:'200px',height:'200px'}}></img>
    </div>
  )
}

//Task-1: update name(ri)-->
// import React from 'react'

// export default function SpreadOperator() {
//     const user1={
//         id:1,
//         username:'Johndoe',
//         email:'john@gmail.com',
//         address:'Mangalore'
//     };
//     //creating a copy with an updated username
//     const user2={...user1,username:"John"};
//   return (
//     <div>
//         <h1 style={{color:'black',backgroundColor:'lightblue'}}>SpreadOperator</h1>

//         {/* Diplaying user information with original username in bold */}
//         <div>
//             <strong>ID:</strong>{user1.id}
//             <strong>,Username:</strong>{user1.username}
//             <strong>,Email:</strong>{user1.email}
//             <strong>,Address:</strong>{user1.address}
//         </div>
// <h2>User Information</h2>
//         {/* Diplaying user information with the updated username */}
//         <div>
//             <strong>ID:</strong>{user2.id} <br/>
//             <strong>,Username:</strong>{user2.username}<br/>
//             <strong>,Email:</strong>{user2.email}<br/>
//             <strong>,Address:</strong>{user2.address}<br/>
//         </div>
        
//     </div>
//   )
//   }
