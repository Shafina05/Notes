// import React,{useEffect, useState} from 'react'

// export default function UseEffect() {
//     const[number,setNumber]=useState(0)
//     const[number1,setNumber1]=useState(0)
    
//     const HandleClick=()=>{
//         setNumber(number+1)
//     }
//     //syntax of useeffect : [] square bracket is-> dependency
//     useEffect(()=>{
//         setNumber1(number*number)
//     },[number])
//   return (
//     <div>UseEffect
//         <h1>{number}</h1>
//         <h1>{number1}</h1>
//         <button onClick={HandleClick}>click</button>
//     </div>
//   )
// }

//Task -1: Multiplication with 3 button increment,decrement,clear


import React, { useState } from 'react';

export default function ThreeBoxes() {
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState(0);

  const handleInputChange = (e) => {
    const value = e.target.value;
    setInputValue(value);

    // Update the result based on the input multiplied by 1
    setResult(value * 1);
  };

  const handleIncrement = () => {
    // Increment the inputValue from 1 to 10
    const newValue = parseInt(inputValue, 10) + 1;
    if (newValue <= 10) {
      setInputValue(newValue.toString());
      setResult(newValue * 1);
    }
  };

  const handleDecrement = () => {
    // Decrement the inputValue from 1 to 0
    const newValue = parseInt(inputValue, 10) - 1;
    if (newValue >= 1) {
      setInputValue(newValue.toString());
      setResult(newValue * 1);
    }
  };

  const handleClearAll = () => {
    // Clear the input and result
    setInputValue('');
    setResult(0);
  };

  return (
    <div>
      <div style={{ display: 'flex' }}>
        <div>
          
          
           <input type="text" value={inputValue} onChange={handleInputChange}/>
         
        </div>
        <div>
          <p>
           1* {inputValue} = {result}
          </p><br></br>
        </div>
        
        <div style={{display:'flex', alignItems:'center'}}>
        <br></br>
        <br></br>
        
          <button onClick={handleIncrement}>Increment</button>
          <button onClick={handleDecrement}>Decrement</button>
          <button onClick={handleClearAll}>Clear All</button>
        </div>
      </div>
    </div>
  );
}

