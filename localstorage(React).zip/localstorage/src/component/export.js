// export const name='Shafina'
// export const phoneno='9591077822'

// //grouped export - here we can use function also
// const age='20';
// const class1='BE';

// export{age,class1}

// //Default export:
// // const College='Sahyadri'
// // export default College

// const car=()=>{
//     const brand='BMW'
//     const Model='1980'
//     console.log('brand'+ brand,'model'+ Model)
// }
// export default car;

//Task-1: Array of object -->
export const students=[
           {slno:1,
             name:'Shafina',
             phone:9591077822,
             email:"shafina@gmail.com",
             address:'Mangalore'},
     {slno:2, 
        name:'Tansira',
        phone:6364220702,
        email:"tansira@gmail.com",
        address:'Moodbidri'},
      {slno:3,
         name:'Nimrisha',
         phone:9591620653,
         email:"nimrisha@gmail.com",
         address:'Mysore'}
    ]
    export default students;
