//Type rfc enter - to get structure of react ,for that intall ES7 extenion

// import React from 'react'
// export default function Arrowfunction() {
//     function Alert(){
//           alert('Hello');
//     }
//     //syntax of arrowfunction in react : const fun_name=(value)=>{
//     const Arrow=(value)=>{
//         //alert('Arrow Function')
//         alert('My name is '+ value)
//     }
//     const Name=(value1,value3)=>{
//         alert('Hello My name is ' +value1 +' and age is '+value3)
//     }
// return (
//   <div>
//         <h1 style={{color:'green',backgroundColor:'yellow'}}>Arrow function</h1>
//         {/*  in button tag onClick to trigger  */}
//         <button onClick={Alert}>click</button>
//         <button onClick={()=>Arrow("Shafina")}>submit</button>
//         <button onClick={()=>Name('shafina','20')}>click here</button>
//   </div>
//   )
// }

//Task_1 : Addition--->
 import React from 'react'
export default function Arrowfunction() {
  function Alert(){
    alert('Hello')
      }
  function add(a,b){
      const value=parseFloat(a+b)
      alert("sum of 20 and 50 is"+value )
      //alert(20+50);
    }
    return (
      <div align='center'>
         <h1 style={{color:'orange'}} >Arrow Functions</h1>
        <button style ={{color:'white',backgroundColor:'magenta'}}onClick={Alert}>Click</button>
        <h1>Addition</h1>
        <button style={{color:'white',backgroundColor:'magenta'}}onClick={()=>add(20,50)}>20+50</button>
    </div>
    )
}

//Task_2:wishes: Good Morning (ri)--->

// import React from 'react';
// export default function ButtonComponent() {
//   const handleTimeButtonClick = () => {
//     const currentTime = new Date();
//     const hours = currentTime.getHours();
//     let greeting;

//     if (hours < 12) {
//       greeting = 'Good Morning';
//     } else if (hours < 18) {
//       greeting = 'Good Afternoon';
//     } else {
//       greeting = 'Good Evening';
//     }

//     alert(`Current time: ${currentTime.toLocaleTimeString()}\n${greeting}`);
//   };

//   const handleSumButtonClick = (value,value1) => {
//     const sum = parseFloat(value+value1);
//     alert(`Sum of 50 + 10 is ${sum}`);
//   };

//   const buttonStyle = {
//     fontSize: '18px',
//     fontWeight:'bold',
//     padding: '10px',
//     margin: '5px',
//     cursor: 'pointer',
//     backgroundColor:'red'
//   };

//   return (
//     <div>
//       <h3 style={{ color: 'blue', backgroundColor: 'lightblue' }}>Arrow Function</h3>
//       <button style={buttonStyle} onClick={handleTimeButtonClick}>
//         Click
//       </button>
//       <h3 style={{ color: 'blue', backgroundColor: 'lightblue' }}>Addition</h3>
//       <button style={buttonStyle} onClick={()=>handleSumButtonClick(50,10)}>
//         50 + 10
//       </button>
//     </div>
//   );
// }

//Task_3:Find square root (ri) -->
//  import React, { useState } from 'react';

// export default function SquareRootFinder() {
//   const [inputText, setInputText] = useState('');

//   const handleInputChange = (event) => {
//     setInputText(event.target.value);
//   };

//   const handleSquareRootButtonClick = () => {
//     const parsedNumber = parseFloat(inputText);

//     if (!isNaN(parsedNumber) && parsedNumber >= 0) {
//       const squareRoot = Math.sqrt(parsedNumber);
//       alert(`The square root of ${parsedNumber} is ${squareRoot.toFixed(2)}`);
//     } else {
//       alert('Please enter a valid non-negative number.');
//     }
//   }

//   const buttonStyle = {
//     fontSize: '18px',
//     fontWeight: 'bold',
//     padding: '10px',
//     margin: '5px',
//     cursor: 'pointer',
//     backgroundColor: 'blue',
//     color: 'white',
//   };

//   return (
//     <div>
//       <h1 style={{ color: 'blue', backgroundColor: 'lightblue' }}>Square Root Finder</h1>
//       <input
//         type="text"
//         placeholder="Enter a number"
//         value={inputText}
//         onChange={handleInputChange}
//         style={{ padding: '10px', fontSize: '16px' }}
//       />
//       <button style={buttonStyle} onClick={handleSquareRootButtonClick}>
//         Find Square Root
//       </button>
//     </div>
//   );
// }