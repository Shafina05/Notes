import React from 'react'

export default function Ternary() {
    var a=10;
    var b=20;
    //if
    if(a==b){
        console.log(true);
        
    }else{
        console.log(false);
   
    }//old Js

    //else-if
// if(){

// }else if(){
//  } else{

//     }


//In react --> if condition:
    a==b?console.log(true):console.log(false);
    //if it is true bg color change to yellow in h1 tag
    const bg=true;
 //  const bg=false;

 //else-if :
 a>=b?console.log(true):a<=b?console.log(false):console.log('Not a number')
    
 return (
    <div>
      <h1 style={{color:'palegreen',backgroundColor:bg==true?'yellow':'red'}}>Ternary Operator</h1>
    </div>
  )
}
