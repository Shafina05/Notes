import React, { useState } from 'react';

export default function Task1_sqr_root() {
  const [number, setNumber] = useState('');
  const [squareRoot, setSquareRoot] = useState(null);

  const calculateSquareRoot = () => {
    const sqrt = Math.sqrt(number);
    setSquareRoot(sqrt);
    return sqrt; // Return the calculated square root
  };

  const result = () => {
    const sqrtResult = calculateSquareRoot();
    alert(`Square Root of ${number} is ${sqrtResult}`);
    //alert(sqrtResult);
  };

  return (
    <div>
      <h1>Using Arrow Function</h1>
      <input
        type="number"
        value={number}
        onChange={(e) => setNumber(Number(e.target.value))}
        placeholder="Enter the number"
      />
      <button onClick={result}>Click</button>
    </div>
  );
}
