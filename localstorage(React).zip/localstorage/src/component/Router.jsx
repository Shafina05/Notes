import React from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './Home'
import ArrowFunction from './Arrowfunction'
import Arraymethod from './Arraymethod'
import Props from './Props'
import UseState from './UseState'
import UseEffect from './UseEffect'
import Table from './Table'

import LocalStorage from './LocalStorage'
import View from './View'
import Update from './Update'

export default function Router() {
  var car='BMw'
  return (
    <div>
        <BrowserRouter>
        <Routes>
            <Route exact path='/' element={<Home/>}/>
            <Route exact path='/Arrow' element={<ArrowFunction/>}/>
            
            <Route exact path='/Array' element={<Arraymethod/>}/>
            <Route exact path='/Props' element={<Props car={car}/>}/>

            <Route exact path='/UseState' element={<UseState/>}/>
            <Route exact path='/UseEffect' element={<UseEffect/>}/>

            <Route exact path='/Table'element={<Table/>}/>

            <Route exact path='/LocalStorage'element={<LocalStorage/>}/>
            <Route exact path='/View'element={<View/>}/>
            
            <Route exact path='/Update/:id'element={<Update/>}/>
        </Routes >
        </BrowserRouter>
    </div>
  )
}
