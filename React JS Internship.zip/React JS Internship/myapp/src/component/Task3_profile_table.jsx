import React from 'react';

export default function Arraymethod() {
    const students=[
        {slno:1,  name:'Shafina',designation:'Software Engineer',department:'IT Department',
         skills:<ul><li>Python</li><li>SQL</li><li>Tableau</li></ul>,
         phone:1234567890,email:"shafina@gmail.com",
         address:'Mangalore'},

      
         {slno:2, name:'Riya',designation:'Data Scientist ',department:'Buiness Intelligence',
         skills:<ul><li>Python</li><li>SQL</li><li>Tableau</li></ul>,
         phone:1234567890,email:"riya@gmail.com",
         address:'Bangalore'},

         {slno:3, name:'Prarthana',designation:'Product Manager', department:'Marketing',
         skills:<ul><li>Excel</li><li>PowerPoint</li></ul>,
         phone:9590547893,email:"prarthana@gmail.com",
         address:'Delhi'},

         {slno:4,name:'Vimarsha',designation:'UI Designer', department:'Design',
         skills:<ul><li>Figma</li></ul>,
         phone:6364895356,email:"vimarsha@gmail.com",
         address:'Mysore'},
 ]
  return (
    <div>
        {/* <h1 align='center'>Employee Information</h1> */}
        <table border={2}cellSpacing={2} cellPadding={8}>
            <th style={{backgroundColor:'peachpuff'}}colSpan={8}>Employee Information</th>
            <tr align='center'style={{backgroundColor:'lightgreen'}} >
              
                <th>Sl.no</th>
                <th >Profile</th>
                <th>Designation</th>
                <th>Department</th>
                <th>Skills</th>
                <th colSpan={2}>Contacts</th>
                <th>Address</th>
            </tr>

            {students.map((value)=>{
                return(
          <tr>
                   <td style={{backgroundColor:'lightblue'}}>{value.slno}</td>
                    <td>{value.name}</td>
                    <td>{value.designation}</td>
                    <td>{value.department}</td>
                    <td>{value.skills}</td>
                    <td>{value.phone}</td>
                    <td>{value.email}</td>
                    <td>{value.address}</td>
                        
                </tr>
                )
            })}
              

        </table>

    </div>
    
  )
}
