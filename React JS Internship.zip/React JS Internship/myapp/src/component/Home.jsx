import React from 'react'
import {Link} from'react-router-dom'

export default function Home() {

  return (
    <div>
      <Link to ='/Arrow'><button>ArrowFunction</button></Link>
      <Link to ='/Array'><button>Array Method</button></Link>
      <Link to ='/Props'><button>Props</button></Link>
      <Link to ='/UseState'><button>UseState</button></Link>
      <Link to ='/UseEffect'><button>UseEffect</button></Link>
      <Link to='/Table'><button>Form with Table</button></Link>

      <Link to='/LocalStorage'><button>LocalStorage</button></Link>

      <Link to='/View'><button>View</button></Link>
      <Link to='/Update'><button>Update</button></Link>

  </div>
   
  )
}
