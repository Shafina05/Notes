import React from 'react'

export default function Props(props,{abcd,car}) {
 console.log(props);
 //To print car name
 console.log(props.car);
  // console.log(abcd);
  return (

    <div>
        <h1 style={{backgroundColor:'black',color:'yellow'}}>Props</h1>
        <h2>My name is {abcd}</h2>
        <h3>{car}</h3>

        <h3>Car is {props.car}</h3>

    </div>
  )
}
