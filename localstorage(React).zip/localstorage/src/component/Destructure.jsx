import React from 'react'
export default function Destructure() {

  const car=['BMW','Benz','Aulto'];
  //old method Destructure
  // const car1=car[0];
  // const car2=car[1];
  // const car3=car[2];
  const[car1,car2,car3]=car /*new method Destructure */
  //create Nested object
  const Students={
    name:'Shafina',
    phone:9591077822,
    address:'Mangalore',
    mark:{
      Hindi:'50',
      English:'70',
      Kannada:'80',
    }
}
const {name,phone,address,mark:{Hindi,English,Kannada}}=Students

return (
   <div align='center'>
       <h1 style={{color:'red',backgroundColor:'green'}} align='center'>Destructure</h1>
       <h2>{car1}</h2>
       <h2>{car2}</h2>
       <h2>{car3}</h2>

       <h3 style={{backgroundColor:'pink'}}>Name:{name}</h3>
       <h3 style={{backgroundColor:'pink'}}>Phone:{phone}</h3>
       <h3 style={{backgroundColor:'pink'}}>Address:{address}</h3>

        {/*      old method 
       <h3 style={{backgroundColor:'pink'}}>Name:{Students.name}</h3>
       <h3 style={{backgroundColor:'pink'}}>Phone:{Students.phone}</h3>
       <h3 style={{backgroundColor:'pink'}}>Address:{Students.address}</h3> */}

       <h3 style={{backgroundColor:'lightblue'}}>Hindi:{Hindi}</h3>
       <h3 style={{backgroundColor:'lightblue'}}>English:{English}</h3>
       <h3 style={{backgroundColor:'lightblue'}}>Kannada:{Kannada}</h3>
    </div>
  )
}

//Task(extra -ri)-->
// import React from 'react';

// export default function Destructure() {
//   const user = {
//     id: 123,
//     username: "johndoe",
//     email: 'john@example.com',
//     address: {
//       street: '123 Main St',
//       city: 'Anytown',
//       zipcode: '12345',
//     },
//     hobbies: ['reading', 'hiking', 'coding'],
//   };

//   // Destructuring the user object
//   const { id, username, email, address, hobbies } = user;

//   return (
//     <div>
//       <h1 style={{ color: 'red', backgroundColor: 'grey' }}>Destructure</h1>
      
//       {/* Displaying user information in a single line */}
//       <div>
//         <strong>ID:</strong> {id}, <strong>Username:</strong> {username}, <strong>Email:</strong> {email},{' '}
//         <strong>Address:</strong> {address.street}, {address.city}, {address.zipcode},{' '}
//         <strong>Hobbies:</strong> {hobbies.join(', ')}
//       </div>

//       {/* Displaying specific details in a formatted way */}
//       <div>
//         <ol>
//           <li>{id}</li>
//           <li>{username}</li>
//           <li>{address.city}</li>
//           <li>{hobbies[0]}</li>
//           <li>{hobbies[1]}</li>
//           <li>{hobbies[2]}</li>
//         </ol>
//       </div>
//     </div>
//   );
// }

