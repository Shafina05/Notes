// 21/Nov/23
import React,{useState} from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';

// import { Link } from 'react-router-dom';
export default function LocalStorage() {
    const navigate=useNavigate();
        let initialValue;
        if(localStorage.getItem('user')==null){
            initialValue=[]
        }
        else{
            initialValue=JSON.parse(localStorage.getItem('user')) //To convert into string
        }
        console.log(initialValue);
    const [Data,setData]=useState({})
    const [value,setValue]=useState(initialValue)
    const HandleChange=(e)=>{
        setData({...Data,[e.target.name]:e.target.value})   //use of spread data
        console.log(Data)

    }
    const HandleSubmit=()=>
    {
        const user_id=value.length==0 ? 1:value[value.length-1].u_id+1
        const allData={
            id:user_id,
            ...Data
        }
        const details=[...value,allData]
        localStorage.setItem('user' ,JSON.stringify(details))
        setValue(details)
        navigate('/View')
    }
  return (
    <div>
        <h1 style={{backgroundColor:'black',color:'yellow'}}>LocalStorage-insert</h1>
        <TextField id="outlined-basic" label="enter your name" variant="outlined" name='name' onChange={HandleChange} /><br/>
        <TextField id="outlined-basic" label="enter your phone" variant="outlined" name='phone' onChange={HandleChange}/><br/>
        <TextField id="outlined-basic" label="enter your email" variant="outlined" name='email' onChange={HandleChange}/><br/>
        <TextField id="outlined-basic" label="enter your address" variant="outlined" name='address' onChange={HandleChange}/><br/><br/>
        <Button variant="contained" color='success' onClick={HandleSubmit}>Submit</Button>

         {/* <Link to={'/view'}><Button variant="contained" color='success'>View</Button></Link> */}
        </div>
  )
}