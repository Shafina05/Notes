import React from 'react'

export default function Task_spread() {

    const userInfo={
        id:'1',
        username:'Johndoe',
        email:'john@gmail.com',
        phone:9591077822,
        address:'Mangalore'
    }
    const updateInfo={
      username:'John'
    }
    const a={...userInfo,...updateInfo}
    console.log(a)


  return (
    <div>
        <h1 style={{color:'black',backgroundColor:'yellow'}}>SpreadOperator</h1>
        <h3>{userInfo.id}</h3>
        <h3>{updateInfo.username}</h3>
    </div>
  )
  }
