
const products = [
    { name: "Apple iPhone 15 Pro Max", price: 159000, description: "High-end mobile phone with advanced features", imageUrl: "mobile.jpeg" },
    { name: "Apple MacBook Air M2", price: 129900, description: "Powerful laptop for seamless multitasking", imageUrl: "laptop.jpeg" },
    { name: "Apple Watch Series 8", price:29999, description: "Smartwatch with health and fitness tracking features", imageUrl: "watch.jpeg" },
    { name: "Apple AirPod Pro", price: 21990, description: "Wireless earbuds for immersive audio experience", imageUrl: "earbuds.jpeg" }
  ];
  
  const productContainer = document.getElementById("product-container");
  
  function createProductCard(product) {
    const card = document.createElement("div");
    card.classList.add("product-card");
    card.innerHTML = `
      <h2>${product.name}</h2>
      <img src="${product.imageUrl}" alt="${product.name}" class="product-image">
      <p>${product.description}</p>
      <p>Price: ${product.price}</p>
      <button class="add-to-cart-btn">Add to Cart 🛒</button>
    `;
    const addToCartBtn = card.querySelector(".add-to-cart-btn");
    addToCartBtn.addEventListener("click", () => addToCart(product));
    return card;
  }
  
  function addToCart(product) {
    alert(`Added to Cart: ${product.name} - $${product.price}`);
  }
  
  products.forEach(product => {
    const card = createProductCard(product);
    productContainer.appendChild(card);
  });