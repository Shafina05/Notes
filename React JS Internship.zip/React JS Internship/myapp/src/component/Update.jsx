import React ,{useEffect, useState}from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useParams } from 'react-router-dom';

export default function Update() {
    let {id}=useParams()
    console.log(id);
    const [Data,setData]=useState([])
    const[single,setSingle]=useState('')

    useEffect(()=>{
        const data=JSON.parse(localStorage.getItem('user'))

       const singleData=data.filter((i,index)=>{return(index==id)})
       console.log(singleData,'single');
        setSingle(...singleData)
        setData(data)
},[])
console.log(single);
const HandleChange=(e)=>{
    setSingle({...single ,[e.target.name]:e.target.value})
}

const HandleUpdate=()=>{
    const UpdatedData=[...Data]
    UpdatedData.splice(id,1,single)
    localStorage.setItem('user',JSON.stringify(UpdatedData))
}
console.log(single,'single');


  return (
    <div align='center' >
         <h1 style={{backgroundColor:'black',color:'yellow'}}>LocalStorage-Update</h1>
        <TextField id="outlined-basic" onChange={HandleChange} value={single.name} label="Enter your name" variant="outlined" name='name'  /><br/><br/>
        <TextField id="outlined-basic"  onChange={HandleChange} value={single.phone} label="Enter your phone number" variant="outlined" name='phone' /><br/><br/>
        <TextField id="outlined-basic" onChange={HandleChange} value={single.email} label="Enter your email" variant="outlined" name='email' /><br/><br/>
        <TextField id="outlined-basic" onChange={HandleChange} value={single.address} label="Enter your address" variant="outlined" name='address' /><br/><br/>
        <Button name='' variant="contained" onClick={HandleUpdate} >Update</Button>

    </div>
  )
}
