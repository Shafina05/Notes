//Task-2 usestate -> Form and table
import React, { useState } from 'react';

export default function Table() {
  const [formData, setFormData] = useState({
    slno:'',
    name: '',
    phoneNumber: '',
    email: '',
    address:'',
    
  });

  const [tableData, setTableData] = useState([]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    // Add the form data to the tableData array
    setTableData([...tableData, formData]);
    // Clear the form fields
    setFormData({
      slno:'',
      name: '',
      phoneNumber: '',
      email: '',
      address:'',
    });
  };

  
  // const formContainerStyle = {
  //   border: '1px solid #ccc',
  //   padding: '20px',
  //   margin: '20px',
  //   backgroundColor: '#f9f9f9',
   
  //   //   backgroundColor:'grey',
  //   //    height:'200px', 
  //   //   width:'200px',
  //   //   border:'15px',
  //   //    marginTop:'150px',
  //   //    marginLeft:'center',
  //   //   border:'2px solid black',
  //   //  borderRadius:'20px',
  // };
  const main={
      display:'flex',
       justifyContent:'center',
       alignItem:'center',
        marginTop:'150px',
       marginLeft:'450px',
       backgroundColor:'pink',
       height:'200px',
       width:'200px',
       cellPadding:'50px'
     }

  return (
    <div >
      <div style={main}>
      <form onSubmit={handleFormSubmit}>
        <label>Enter Name:
          <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
        </label>
        <br />

        <label> Enter Phone Number:
          <input type="text" name="phoneNumber"value={formData.phoneNumber} onChange={handleInputChange}/>
        </label>
        <br />

        <label>Enter Email:
          <input type="text" name="email" value={formData.email} onChange={handleInputChange}/>
        </label>
        <br />

        <label>Address:
          <input type="text" name="address" value={formData.address} onChange={handleInputChange} />
        </label>
        <br />
      
        <button style={{backgroundColor:'palegreen'}} type="submit">Submit</button>
      </form>
      </div>
    
<br></br>
        <h1 align='center'>Table</h1>
      <table  align='center' border={2} cellPadding={8} cellSpacing={4}>
        <thead>
        <th style={{backgroundColor:'pink'}}colSpan={6}>Student Information</th>
          <tr >
            
            <th>sl.no</th>
            <th>Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Address</th>
         </tr>
        </thead>
        <tbody>
          {tableData.map((data, index) => (
            <tr key={index}>
                <td >1</td>
              <td>{data.name}</td>
             <td>{data.phoneNumber}</td>
              <td>{data.email}</td>
              <td>{data.address}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


// import React, { useState } from 'react';

// export default function Table() {
//   const [formData, setFormData] = useState({
//     slno:'',
//     name: '',
//     phoneNumber: '',
//     email: '',
//     address:'',
//   });

//   const [tableData, setTableData] = useState([]);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleFormSubmit = (e) => {
//     e.preventDefault();
//     setTableData([...tableData, formData]);
//     setFormData({
//       slno:'',
//       name: '',
//       phoneNumber: '',
//       email: '',
//       address:'',
//     });
//   };

//   const formContainerStyle = {
//     // border: '1px solid #ccc',
//     // padding: '20px',
//     // margin: '20px',
//     // backgroundColor: '#f9f9f9',
//     color:'red',
//       backgroundColor:'pink',
//        height:'300px', 
//       width:'400px',
//       border:'15px',
//        marginTop:'150px',
//       border:'2px solid black',
//      borderRadius:'20px',
//   };
//   const main={
//       display:'flex',
//        justifyContent:'center',
//        alignItem:'center',
//      }
    
//   const customTableStyle = {
//     margin: '0 auto',
//     backgroundColor: 'lightblue',
//     border: '2px solid black',
//     borderCollapse: 'collapse',
//   };

//   return (
//     <div style={formContainerStyle}>
//       <div style={main}>
//         <form onSubmit={handleFormSubmit}>
//           {/* ... (your form inputs and labels) ... */}
//           <button type="submit">Submit</button>
//         </form>
//       </div>

//       <h1 align='center'>Table</h1>
//       <table style={customTableStyle}> 
//         {/* ... (your table headers and rows) ... */}
//       </table>
//     </div>
//   );
// }
