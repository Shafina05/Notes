import React from 'react'

export default function Task() {
  // syntax of Arrowfunction : const fun_name=(value)=>{
  const handleTime=()=>{
    const currentHour=new Date().toLocaleTimeString()
console.log(currentHour);
    let message
    if (currentHour<='12.00'){
      message='Good Morning'
    }
    else if(currentHour>='12.00' ){
      message='Good Afternoon'
    }
    else{
      message='Good Evening'
    }
  alert(message+" "+currentHour)
}

 return ( 
    <div align='center'>
        <button className='clickbutton' onClick={()=>handleTime()}>Click</button>
    </div>
  )
}
