import React from 'react';
// import logo from './logo.svg';
import './App.css';
//  import './external.css' 
// import Arrowfunction from './component/Arrowfunction';
// import Arraymethod from './component/Arraymethod';
// import Destructure from './component/Destructure';
// import SpreadOperator from './SpreadOperator';
// import Ternary from './component/Ternary';
// import Import from './component/Import';
// import Props from './component/Props';
import Router from './component/Router'

// import Task from'./component/Task';
// import Task1_sqr_root from './component/Task1_sqr_root';
// import Task2_spread from './component/Task2_spread';
// import Task3_profile_table from './component/Task3_profile_table';


function App() {
  //props
  // var name='Rahul'
  // //array for prop
  // const fruit=['Apple','Banana','Mango']
// const car=[BMw]


  //css property For creating card
// const hello={
//    color:'red',
//   backgroundColor:'pink',
//    height:'300px', 
//   width:'400px',
//   border:'15px',
//    marginTop:'150px',
//   border:'2px solid black',
//  borderRadius:'20px',
//   boxShadow:'10px 10px  5px black'

//  };
// const main={
//    display:'flex',
//    justifyContent:'center',
  //  alignItem:'center',
//  }

   
 return(

  <div>
    {/* component */}
        {/* <Arrowfunction />  */}
         {/* <Arraymethod/> <br></br> */}
        {/* <Destructure/> */}
        {/* <SpreadOperator/><br></br> */}
        {/* <Ternary/><br></br> */}
        {/* <Import/> */}
        
        {/* <Props abcd={name} car={car}/> */}

        <Router/>
        
       
        {/* <Task/> */}
    {/* <Task1_sqr_root/><br></br> */}
    {/* <Task2_spread/> <br></br>
    <Task3_profile_table/><br></br> */}

  </div>
  // For creating card
//     <div className="App" style={main}>
//         <div style={hello}  >
//             <h1>Good Morning</h1>
//             <p>Hello</p>

//           To import that file
          // <Arrowfunction />
          // <Arraymethod/>
       
    



        // </div>

        
//  {/* <h1 style={{color:'red',backgroundColor:'yellow',marginTop:'250px'}}>Hello</h1>
// Internal style -->
// <h2 style={hello}>Hello React</h2>
// <h3 className='box'>Using External CSS</h3>  */}

//     </div>


   );
   }
  
  
export default App;
