// import React from 'react'
// import  {name,phoneno,age,class1} from './export'
// // import { phoneno } from './export'
// //import {College} from './export'
// import {car} from './export'

// export default function Import() {
//   return ( 
//     <div>
//         <h1 style={{color:'red',backgroundColor:'green'}}>Import</h1>
//         <h2>My name is {name}</h2>
//         <h2>My phone number is {phoneno}</h2>
//         <h2>Age :{age}</h2>
//         <h2>class: {class1}</h2>
//         {/* <h3>College {College}</h3> */}
//         {car()}
//     </div>
//   )
// }

//Task-1:
import React from 'react' 
import {students} from './export'

export default function Import() {
  return (
    <div>
      <h1 style={{color:'red',backgroundColor:'yellow'}} align='center'>Import</h1>

           <table border={2} align='center'cellSpacing={3} cellPadding={12} >
             <tr>
              <th>sl.no</th>
                <th>Name</th>
                <th>Phone</th>
                 <th>Email</th>
                 <th>Address</th>
            </tr>
          {students.map((val,i)=>
        
            <tr> 
                <td>{val.slno}</td>
                <td>{val.name}</td>
                <td>{val.phone}</td>
                <td>{val.email}</td>
                <td>{val.address}</td>
               </tr>
          )
}
     </table> 
    </div>
  )
}

