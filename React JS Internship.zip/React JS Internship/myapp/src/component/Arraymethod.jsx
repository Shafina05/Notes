import React from 'react'
export default function Arraymethod() {
    const car=['Audi','BMW','Benz']
    const student=[{
        name:'Rahul',
        age:23,
        email:"rahul@gmail.com"
    },
   { name:'Rahul',
        age:23,
        email:"rahul@gmail.com"
}
]
return (
    <div>
        <h1 style={{color:'black'}}>Array Method</h1>
    {car.map((item)=>{
        return(<h1>{item}</h1>)
        })}
        
        {/* <table border={2} cellPadding={4} cellSpacing={2}> */}
            <table border={2}>
            <tr>
                <th>sl.no</th>
                <th>Name</th>
                <th>Age</th>
                <th>Email</th>
            </tr>
            {student.map((value)=>{
                return(
                    <tr>
                        <td>1</td>
                        <td>{value.name}</td>
                        <td>{value.age}</td>
                        <td>{value.email}</td>
                    </tr>
                )
            })}
        </table> 

    </div>
  )
}

//Task_1:Table(normal ) -->
//   import React from 'react'
// export default function Arraymethod() {

//     const students=[
//         {slno:1, name:'Shafina',last_name:'M',phone:9591077822,email:"shafina@gmail.com",address:'Mangalore'},
//        {slno:2, name:'Tansira',last_name:'M',phone:6364220702,email:"tansira@gmail.com",address:'Moodbidri'},
//        {slno:3, name:'Nimrisha',last_name:'M',phone:9591620653,email:"nimrisha@gmail.com",address:'Mysore'}
//           ]

// return (
//  <div>
//     <h3 style={{color:'red'}}align='center' >Array Method</h3>
//         <table border={2} align='center' cellSpacing={2} cellPadding={4}>
//             <tr>
//                 <th>Sl.no</th>
//                 <th colSpan={2}>Full Name</th>
//                 <th>Phone</th>
//                 <th>Email</th>
//                 <th>Address</th>
//              </tr>

//             {students.map((value)=>{
//                 return(
            
//                 <tr>
//                     <td>{value.slno}</td>
//                     <td>{value.name}</td>
//                     <td>{value.last_name}</td>
//                     <td>{value.phone}</td>
//                     <td>{value.email}</td>
//                     <td>{value.address}</td>
//                 </tr>
//                 )
//             })}
//         </table>

//     </div>
//   )
// }

//Task_2: Table(profile : put img) -->
//  import React from 'react';

// export default function Arraymethod() {
//   const students = [
//     {
//       serialNo: 1,
//       fullName: "Riya",
//       designation:'Product Manager',
//       department:'Marketing',
//       email: "Riyasonal@gmail.com",
//       phone:99875475632,
//       address: "Manglore",
//       skills: ['java', 'c++', 'c'],
//     },
//     {
//       serialNo: 2,
//       fullName: "Sudheeksha",
//       designation:'Data Scientist',
//       department:'Buisness Intelligence',
//       email: "sudhee@gmail.com",
//       phone:88763683973,
//       address: "Udupi",
//       skills: ['java', 'c++'],
//     },
//     {
//       serialNo: 3,
//       fullName: "Shafina",
//       designation: 'Software Engineer',
//       department:'IT department',
//       email: "Shafina@gmail.com",
//       phone:76547936473,
//       address: "Moodbidri",
//       skills: ['java', 'python'],
//     },
//     {
//       serialNo: 4,
//       fullName: "Vimarsha",
//       designation:'Data Scientist',
//       department:'Buisness Intelligence',
//       email: "Vimarsha34@gmail.com",
//       phone:89687564334,
//       address: "karkala",
//       skills: ['python', 'c++', 'java'],
//     },
//     {
//       serialNo: 5,
//       fullName: "Sinchana",
//       designation: 'Software Engineer',
//       department:'IT department',
//       email: "Sinchana@gmail.com",
//       phone:8800868897,
//       address: "Manglore",
//       skills: ['java', 'python'],
//     },
//   ];
//   const numbers = Array.from({ length: 10 }, (_, index) => index + 1);
//   const squares = numbers.map((number) => number ** 2);
//   return (
//     <div>
//       <h1 style={{ color: 'blue', backgroundColor: '' }}>Arraymethod</h1>
//       <table border={2} align='center'>
//         <tr style={{ backgroundColor: 'lightblue', fontWeight: 'bold' }}>
//           <th>Serial No</th>
//           <th>Profile </th>
//           <th>Designation</th>
//           <th>Department</th>
//           <th>Technical Skills</th>
//           <th colSpan={2}>Contact Details</th>
//           <th>Address</th>
//         </tr>
//         {students.map((student) => {
//           return (
//             <tr key={student.serialNo}>
//               <td style={{ backgroundColor: 'pink', fontWeight: 'bold' }}>{student.serialNo}</td>
//               <td>
//                 <div style={{ display: 'flex', alignItems: 'center' }}>
//                   <img
//                     src={`https://picsum.photos/50/50?seed=${student.fullName}`}
//                     alt={student.fullName}
//                     style={{ width: '50px', height: '50px', borderRadius: '50%', marginRight: '10px' }}
//                   />
//                   <span>{student.fullName}</span>
//                 </div>
//               </td>
//               <td>{student.designation}</td>
//               <td>{student.department}</td>
//               <td>
//                 <ol style={{ listStyle:'inside', padding: 0 }}>
//                   {student.skills.map((skill, index) => (
//                     <li key={index}>{skill}</li>
//                   ))}
//                 </ol>
//               </td>
//               <td>{student.phone}</td>
//               <td>{student.email}</td>
//               <td>{student.address}</td>
//             </tr>
//           );
//         })}
//       </table>
//       <div>
//         <h1>Array Method</h1>
//         <p>Numbers: {numbers.join(', ')}</p>
//         <p>Squares: {squares.join(', ')}</p>
//       </div>
//     </div>
//   );
// }